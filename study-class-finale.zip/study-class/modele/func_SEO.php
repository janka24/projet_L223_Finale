<?php
///
function Format_Name($Var) {
	$NAME = $Var;
	$NAME = trim($NAME);
	$NAME = html_entity_decode($NAME);
	$NAME = preg_replace('#Ç#', 'c', $NAME);
	$NAME = preg_replace('#ç#', 'c', $NAME);
	$NAME = preg_replace('#è|é|ê|ë#', 'e', $NAME);
	$NAME = preg_replace('#È|É|Ê|Ë#', 'e', $NAME);
	$NAME = preg_replace('#à|á|â|ã|ä|å#', 'a', $NAME);
	$NAME = preg_replace('#@|À|Á|Â|Ã|Ä|Å#', 'a', $NAME);
	$NAME = preg_replace('#ì|í|î|ï#', 'i', $NAME);
	$NAME = preg_replace('#Ì|Í|Î|Ï#', 'i', $NAME);
	$NAME = preg_replace('#ð|ò|ó|ô|õ|ö#', 'o', $NAME);
	$NAME = preg_replace('#Ò|Ó|Ô|Õ|Ö#', 'O', $NAME);
	$NAME = preg_replace('#ù|ú|û|ü#', 'u', $NAME);
	$NAME = preg_replace('#Ù|Ú|Û|Ü#', 'u', $NAME);
	$NAME = preg_replace('#ý|ÿ#', 'y', $NAME);
	$NAME = preg_replace('#Ý#', 'y', $NAME);
	$NAME = preg_replace('#Ñ#', 'n', $NAME);
	$NAME = str_replace(' ', '-', $NAME);
	$NAME = str_replace(' ', '-', $NAME);
	$NAME = str_replace('---', '-', $NAME);
	$NAME = str_replace('--', '-', $NAME);
	$NAME = str_replace('--', '-', $NAME);
	return $NAME;
}

///
function SEO($Var) {
	$NAME	= Format_Name($Var);
	$NAME	= str_replace('"', '', $NAME);
	$SEO	= mb_strtolower($NAME, 'UTF-8');
	return $SEO;
}
?>
