<?php
// Sans quoi on ne peut pas utiliser "précédent"...
session_cache_limiter(false);

//	On démarre la session
session_start();
$SESSION_ID = SESSION_ID();

//	On se connecte à la BDD
require("../modele/cnx.php");
?>
