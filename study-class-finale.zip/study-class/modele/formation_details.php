<?php
$RsFormation = mysqli_query($db, "
SELECT 
Formations.Id_Formation, 
Formations.Formation, 
Formations.SEO, 
Formations.Titre, 
Formations.Synthese, 
Formations.Descriptif, 
Formations.Duration, 
Formateurs.Formateur, 
Formateurs.Public_Email,
Formateurs.Photo  
FROM Formations, Formateurs 
WHERE 
Formations.Id_Formateur = Formateurs.Id_Formateur 
AND Formations.Active = '1' 
AND Formations.SEO = '$Page'");
$Formation = mysqli_fetch_assoc($RsFormation);
?>
