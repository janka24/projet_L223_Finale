<?php
echo '
<section id="formateurs">
	<div class="container py-5 mt-4">
		<div class="row d-flex justify-content-center">
			<div class="col-md-10 col-xl-8 text-center">
				<h3>Nos formateurs</h3>
				<p class="mb-4 pb-2 mb-md-5 pb-md-0">
				Les qualités de nos formateurs qui maitrîses les outils et méthodes d\'apprentissage.
				</p>
			</div>
		</div>

		<div class="row text-center">';
		
			foreach($Liste_Formateurs AS $Formateur) {
				echo '
				<div class="col-md-4 mb-4 mb-md-0">
					<div class="card">
						<div class="card-body py-4 mt-2">
							<div class="d-flex justify-content-center mb-4">
								<img src="'.$Base_URL.'/assets/images/formateurs/'.$Formateur['Photo'].'.jpg" alt="'.$Formateur['Formateur'].'" title="'.$Formateur['Formateur'].'" class="rounded-circle shadow-1-strong" width="100" height="100">
							</div>

							<h5 class="f-w">'.$Formateur['Formateur'].'</h5>
							<h6 class="fw-bold mb-4">Développement web</h6>
							<hr>
							'.$Formateur['Presentation'].'
							
							<div class="trainer mt-4">
								<div class="trainer-profile text-align-center">
									<a href="'.$Formateur['Portfolio'].'" target="_blank"><button type="submit" class="j-btn">Visiter mon site</button></a>
								</div>
							</div>
							
						</div>
					</div>
				</div>';
			}

		echo '
		</div>
	</div>
</section>';
?>
