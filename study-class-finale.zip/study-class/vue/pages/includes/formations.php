<?php
echo '
<div class="divider" id="formations"></div>

<section id="formation" class="formation">
	<div class="container">
		<div class="row">';
		
			foreach($Liste_Formation AS $Formation) {
				echo '
				<div class="col-lg-4 col-md-6 d-flex align-items-stretch">
					<div class="item">
						<img src="'.$Base_URL.'/assets/images/formations/'.$Formation['SEO'].'.png" class="img-fluid" alt="'.$Formation['Formation'].'">
						<div class="content">
							<div class="d-flex justify-content-between align-items-center mb-3">
								<h4>Formation '.$Formation['Formation'].'</h4>
								<p class="duration">'.$Formation['Duration'].'</p>
							</div>

							<h5><a href="#">'.$Formation['Titre'].'</a></h5>
							<div class="next d-flex justify-content-between align-items-center">
								<div class="d-flex align-items-center">
									<a href="'.$Base_URL.'/formation/'.$Formation['SEO'].'.html"><button type="submit" class="btn">Découvrir</button></a>
								</div>
							</div>
						</div>
					</div>
				</div>';
			}

		echo '
		</div>
	</div> 
</section>';
?>

