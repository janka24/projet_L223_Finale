<?php
echo '
<div id="myCarousel" class="carousel slide" data-bs-ride="carousel">
	<div class="carousel-inner">
		<div class="carousel-item active">
			<img src="'.$Base_URL.'/assets/images/carousel/header-1.jpg" style="width:100%">
			<div class="d-flex h-80 align-items-center justify-content-center slider-content">
            <div class="container">
                <div class="row">
                    <div class="col-md">
                        <h1 class="slide-title">Studyclass - 100% </h1>
                        <h2 class="slide-text ">Formation à votre rythme</h2>
                        <p><a class="btn btn-lg btn-primary" href="#">Découvrir</a></p>
                    </div>
                </div>
            </div>
        </div>
	</div>
</div>';
?>
