<?php
require("./assets/js/tinymce/import.php");

$Id_Formation_Selected = $_POST['Select_Formation'] ?? "";
$Id_Formateur_Selected = $_POST['Select_Formateur'] ?? "";
$Id_Administrateur_Selected = $_POST['Select_Administrateur'] ?? "";

echo '
<div class="container">
<h1>Site Admin</h1>

<div class="row mt-4">
	<div class="col-lg-4">
		<form action="" method="post">
			<div class="input-group mb-3">
				<span class="input-group-text">Administrer une formation :</span>
				<select name="Select_Formation" class="form-select" autocomplete="off">
					<option value="">Sélectionner</option>';

					$RsFormations = mysqli_query($db, "SELECT * FROM Formations ORDER BY Formation");
					while ($data_Formations = mysqli_fetch_assoc($RsFormations)) {
						$Id_Formation		= $data_Formations['Id_Formation'];
						$Formation			= $data_Formations['Formation'];

						echo '
						<option value="'.$Id_Formation.'"'; IF ($Id_Formation==$Id_Formation_Selected) { echo ' selected'; } echo '>'.$Formation.'</option>';
					}

				echo '
				</select>
				<button type="submit" class="btn btn-primary"><i class="fa fa-check"></i></button>
			</div>
		</form>
	</div>

	<div class="col-lg-4">
		<form action="" method="post">
			<div class="input-group mb-3">
				<span class="input-group-text">Administrer un formateur :</span>
				<select name="Select_Formateur" class="form-select" autocomplete="off">
					<option value="">Sélectionner</option>';

					$RsFormateurs = mysqli_query($db, "SELECT * FROM Formateurs ORDER BY Formateur");
					while ($data_Formateurs = mysqli_fetch_assoc($RsFormateurs)) {
						$Id_Formateur		= $data_Formateurs['Id_Formateur'];
						$Formateur			= $data_Formateurs['Formateur'];

						echo '
						<option value="'.$Id_Formateur.'"'; IF ($Id_Formateur==$Id_Formateur_Selected) { echo ' selected'; } echo '>'.$Formateur.'</option>';
					}

				echo '
				</select>
				<button type="submit" class="btn btn-primary"><i class="fa fa-check"></i></button>
			</div>
		</form>
	</div>

	<div class="col-lg-4">
		<form action="" method="post">
			<div class="input-group mb-3">
				<span class="input-group-text">Administrateurs :</span>
				<select name="Select_Administrateur" class="form-select" autocomplete="off">
					<option value="">Sélectionner</option>';

					$RsAdministrateurs = mysqli_query($db, "SELECT * FROM Administrateurs ORDER BY Administrateur");
					while ($data_Administrateurs = mysqli_fetch_assoc($RsAdministrateurs)) {
						$Id_Administrateur		= $data_Administrateurs['Id_Administrateur'];
						$Administrateur			= $data_Administrateurs['Administrateur'];

						echo '
						<option value="'.$Id_Administrateur.'"'; IF ($Id_Administrateur==$Id_Administrateur_Selected) { echo ' selected'; } echo '>'.$Administrateur.'</option>';
					}

				echo '
				</select>
				<button type="submit" class="btn btn-primary"><i class="fa fa-check"></i></button>
			</div>
		</form>
	</div>
</div>';

IF ($Id_Formation_Selected!='') {
	echo $Import_Content;
	require("incs/formation.php");
}

IF ($Id_Formateur_Selected!='') {
	echo $Import_Content;
	require("incs/formateur.php");
}

IF ($Id_Administrateur_Selected!='') {
	require("incs/administrateur.php");
}

echo '
</div>';
?>
