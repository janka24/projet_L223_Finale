<?php
echo '
<form action="" method="post" class="mt-4 mb-4 up-fiche">
	<input type="hidden" name="Select_Formation" value="'.$Id_Formation_Selected.'">
	<input type="hidden" name="UP_Formation" value="Yes">
	<input type="hidden" name="Tab" value="Fiche">

	<div class="input-group mb-3">
		<span class="input-group-text">Active :</span>
		<select name="Active" class="form-select" autocomplete="off">
			<option value="1"'; IF ($Active==1) { echo ' selected'; } echo '>Oui</option>
			<option value="0"'; IF ($Active==0) { echo ' selected'; } echo '>Non</option>
		</select>
	</div>

	<div class="input-group mb-3">
		<span class="input-group-text">Formation :</span>
		<input type="text" class="form-control" name="Formation" value="'.$Formation.'">
	</div>

	<div class="input-group mb-3">
		<span class="input-group-text">Titre :</span>
		<input type="text" class="form-control" name="Titre" value="'.$Titre.'">
	</div>

	<span class="input-group-text mt-3">Synthèse :</span>
	<textarea class="form-control editor" name="Synthese">'.$Synthese.'</textarea>

	<span class="input-group-text mt-3">Descriptif :</span>
	<textarea class="form-control editor" name="Descriptif">'.$Descriptif.'</textarea>

	<div class="input-group mb-3 mt-3">
		<span class="input-group-text">Formateur :</span>
		<select name="Formateur" class="form-select" autocomplete="off">
			<option value="">Sélectionner</option>';
			
			$RsFormateurs = mysqli_query($db, "SELECT * FROM Formateurs ORDER BY Formateur");
			while ($data_Formateurs = mysqli_fetch_assoc($RsFormateurs)) {
				$IdFormateur		= $data_Formateurs['Id_Formateur'];
				$Formateur			= $data_Formateurs['Formateur'];

				echo '
				<option value="'.$IdFormateur.'"'; IF ($IdFormateur==$Id_Formateur) { echo ' selected'; } echo '>'.$Formateur.'</option>';
			}

		echo '
		</select>
	</div>

	<div class="input-group mb-3 mt-3">
		<span class="input-group-text">Durée :</span>
		<input type="text" class="form-control" name="Duration" value="'.$Duration.'">
	</div>

	<button type="submit" class="btn btn-primary">Modifier</button>
</form>';
?>
