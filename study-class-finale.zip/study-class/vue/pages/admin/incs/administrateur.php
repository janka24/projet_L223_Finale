<?php
///
IF (isset($_POST['UP_Administrateur'])) {
	$Administrateur	= $_POST['Administrateur'];
	$User			= $_POST['User'];
	$Pass			= $_POST['Pass'];

	mysqli_query($db, "
	UPDATE Administrateurs SET 
	Administrateur	= \"$Administrateur\", 
	User			= \"$User\" 
	WHERE Id_Administrateur = '$Id_Administrateur_Selected'");
	
	IF ($Pass!="") {
		$Encode_Password = sha1(md5($Pass));

		///
		mysqli_query($db, "UPDATE Administrateurs SET Pass = \"$Encode_Password\" WHERE Id_Administrateur = '$Id_Administrateur_Selected'");
	}
}

///
$RsAdministrateur = mysqli_query($db, "SELECT * FROM Administrateurs WHERE Id_Administrateur = '$Id_Administrateur_Selected'");
$data_Administrateur = mysqli_fetch_assoc($RsAdministrateur);
	$Administrateur		= $data_Administrateur['Administrateur'];
	$User			= $data_Administrateur['User'];
	$Pass			= $data_Administrateur['Pass'];

///
echo '
<hr>
<form action="" method="post" class="mt-4 mb-4 up-fiche">
	<input type="hidden" name="Select_Administrateur" value="'.$Id_Administrateur_Selected.'">
	<input type="hidden" name="UP_Administrateur" value="Yes">

	<h4 class="mb-4">Modifier la fiche administrateur :</h4> 

	<div class="input-group mb-3">
		<span class="input-group-text">Admin :</span>
		<input type="text" class="form-control" name="Administrateur" value="'.$Administrateur.'" readonly>
	</div>

	<div class="input-group mb-3">
		<span class="input-group-text">Utilisateur :</span>
		<input type="text" class="form-control" name="User" value="'.$User.'">
	</div>

	<div class="input-group mb-3">
		<span class="input-group-text">Pass :</span>
		<input type="password" class="form-control" name="Pass" value="">
	</div>
	<button type="submit" class="btn btn-primary">Modifier</button>
</form>';
?>

