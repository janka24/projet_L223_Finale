<?php
echo '
<div class="row mt-4">
	<div class="col-lg-3">';
		///
		$RsModules_Niveaux = mysqli_query($db, "
		SELECT Formation_Modules.Id_Niveau, Niveau_Label FROM 
		Formation_Modules, Formation_Niveaux 
		WHERE Formation_Modules.Id_Niveau = Formation_Niveaux.Id_Niveau 
		AND Id_Formation = '$Id_Formation_Selected' 
		GROUP BY Formation_Modules.Id_Niveau");
		while ($data_Modules_Niveaux = mysqli_fetch_assoc($RsModules_Niveaux)) {
			$Id_Niveau = $data_Modules_Niveaux['Id_Niveau'];
			$Niveau_Label = $data_Modules_Niveaux['Niveau_Label'];
			echo '
			<h5>'.$Niveau_Label.' :</h5>

			<ul class="list-group ms-0">';

				$RsModules = mysqli_query($db, "
				SELECT * FROM 
				Formation_Modules, Formation_Niveaux 
				WHERE Formation_Modules.Id_Niveau = Formation_Niveaux.Id_Niveau 
				AND Id_Formation = '$Id_Formation_Selected' 
				AND Formation_Modules.Id_Niveau = '$Id_Niveau'");
				while ($data_Modules = mysqli_fetch_assoc($RsModules)) {
					$Id_Module		= $data_Modules['Id_Module'];
					$Niveau_Label	= $data_Modules['Niveau_Label'];
					$Titre			= $data_Modules['Titre'];

					echo '
					<li class="list-group-item">
						<form action="" method="post" name="Mod_'.$Id_Module.'">
							<input type="hidden" name="Select_Formation" value="'.$Id_Formation_Selected.'">
							<input type="hidden" name="Select_Module" value="'.$Id_Module.'">
							<input type="hidden" name="Tab" value="Programme">
							<a href="#" onclick="document.forms[\'Mod_'.$Id_Module.'\'].submit()">'.$Titre.' <i class="fa fa-chevron-right ms-2 float-end"></i></a>
						</form>
					</li>';
				}

			echo '
			</ul>';
		}
	echo '
	</div>
	<div class="col-lg-9">';
		IF ($Id_Module_Selected=="") {
			echo "<h4>Merci de bien vouloir sélectionner un module.</h4>";
		}

		Else {
			$RsModule_Selected = mysqli_query($db, "SELECT * FROM Formation_Modules WHERE Id_Module = '$Id_Module_Selected'");
			$data_Module_Selected = mysqli_fetch_assoc($RsModule_Selected);
				$Module	= $data_Module_Selected['Titre'] ?? '';
			echo '
			<div class="row justify-content-xl-center gy-3 gy-sm-4">
				<h4>Module : '.$Module.'</h4>

				<ul class="nav nav-tabs" role="tablist2">
					<li class="nav-item" role="presentation">
						<button class="nav-link active" id="Formation-tab" data-bs-toggle="tab" data-bs-target="#Formation" type="button" role="tab" aria-controls="Formation" aria-selected="true">Formation</button>
					</li>
					<li class="nav-item" role="presentation">
						<button class="nav-link" id="Ressources-tab" data-bs-toggle="tab" data-bs-target="#Ressources" type="button" role="tab" aria-controls="Ressources" aria-selected="false">Ressources</button>
					</li>
					<li class="nav-item" role="presentation">
						<button class="nav-link" id="Exercices-tab" data-bs-toggle="tab" data-bs-target="#Exercices" type="button" role="tab" aria-controls="Exercices" aria-selected="false">Exercices</button>
					</li>
				</ul>

				<div class="tab-content">
					<div class="tab-pane fade show active" id="Formation" role="tabpanel" aria-labelledby="Formation-tab">
						<p>Formation...</p>
					</div>
					<div class="tab-pane fade" id="Ressources" role="tabpanel" aria-labelledby="Ressources-tab">
						<p>Ressources...</p>
					</div>
					<div class="tab-pane fade" id="Exercices" role="tabpanel" aria-labelledby="Exercices-tab">
						<p>Exercices...</p>
					</div>
				</div>
			</div>';
		}
	echo '
	</div>
</div>';
?>
