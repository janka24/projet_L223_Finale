<?php
//	New_Version
IF (isset($_POST['New_Version']) AND $_POST['New_Version']!="") {
	$New_Version = $_POST['New_Version'];

	mysqli_query($db,"INSERT INTO Evaluations_Forms (`Id_Form`, `Id_Formation`, `Id_Niveau`, `Version`, `Coefficient`) VALUES (NULL, \"$Id_Formation_Selected\", \"$Id_Niveau_Selected\", \"$New_Version\", \"1\")");
}

//	UP_Coeffient
IF (isset($_POST['UP_Coeffient']) AND $_POST['UP_Coeffient']!="") {
	$UP_Coeffient = $_POST['UP_Coeffient'];

	mysqli_query($db, "UPDATE `Evaluations_Forms` SET Coefficient = \"$UP_Coeffient\" WHERE Id_Form = '$Id_Form_Selected'");
}

//	Add_Question
IF (isset($_POST['Add_Question']) AND $_POST['Question']!="") {
	$Question = $_POST['Question'];

	mysqli_query($db,"INSERT INTO Evaluations_Questions (`Id_Question`, `Id_Form`, `Question`) VALUES (NULL, \"$Id_Form_Selected\", \"$Question\")");
}

//	UP_Question
IF (isset($_POST['UP_Question']) AND $_POST['Question']!="") {
	$Id_Question	= $_POST['Id_Question'];
	$Question		= $_POST['Question'];

	mysqli_query($db, "
	UPDATE `Evaluations_Questions` SET 
	Question = \"$Question\" 
	WHERE Id_Question = '$Id_Question'");
}

//	Add_Response
IF (isset($_POST['Add_Response']) AND $_POST['Response_Type']!="" AND $_POST['Reponse']!="" AND $_POST['Points']!="") {
	$Id_Question	= $_POST['Id_Question'];
	$Response_Type	= $_POST['Response_Type'];
	$Reponse		= $_POST['Reponse'];
	$Points			= $_POST['Points'];

	mysqli_query($db,"INSERT INTO Evaluations_Reponses (`Id_Reponse`, `Id_Question`, `Type`, `Reponse`, `Points`) VALUES (NULL, \"$Id_Question\", \"$Response_Type\", \"$Reponse\", \"$Points\")");
}

//	UP_Response
IF (isset($_POST['UP_Response']) AND $_POST['Response_Type']!="" AND $_POST['Reponse']!="" AND $_POST['Points']!="") {
	$Id_Reponse		= $_POST['Id_Reponse'];
	$Response_Type	= $_POST['Response_Type'];
	$Reponse		= $_POST['Reponse'];
	$Points			= $_POST['Points'];

	mysqli_query($db, "
	UPDATE `Evaluations_Reponses` SET 
	Type = \"$Response_Type\", 
	Reponse = \"$Reponse\", 
	Points = \"$Points\" 
	WHERE Id_Reponse = '$Id_Reponse'");
}

///
echo '
<div class="row mt-4">
	<form action="" method="post">
		<input type="hidden" name="Select_Formation" value="'.$Id_Formation_Selected.'">
		<input type="hidden" name="Tab" value="Evaluations">

		<div class="input-group mb-3">
			<select name="Select_Niveau" class="form-select" autocomplete="off">
				<option value="">Sélectionnez</option>';
			
				///
				$RsModules_Niveaux = mysqli_query($db, "
				SELECT Formation_Modules.Id_Niveau, Niveau_Label FROM 
				Formation_Modules, Formation_Niveaux 
				WHERE Formation_Modules.Id_Niveau = Formation_Niveaux.Id_Niveau 
				AND Id_Formation = '$Id_Formation_Selected' 
				GROUP BY Formation_Modules.Id_Niveau");
				while ($data_Modules_Niveaux = mysqli_fetch_assoc($RsModules_Niveaux)) {
					$Id_Niveau = $data_Modules_Niveaux['Id_Niveau'];
					$Niveau_Label = $data_Modules_Niveaux['Niveau_Label'];
					
					echo '<option value="'.$Id_Niveau.'"'; IF ($Id_Niveau==$Id_Niveau_Selected) { echo ' selected'; } echo '>'.$Formation.' : '.$Niveau_Label.'</option>';
				}

			echo '
			</select>
			<button type="submit" class="btn btn-primary"><i class="fa fa-check"></i></button>
		</div>
	</form>';
	
	IF ($Id_Niveau_Selected!="") {
		echo '
		<div class="row mt-4">
			<div class="col-lg-3">
				<form action="" method="post">
					<input type="hidden" name="Select_Formation" value="'.$Id_Formation_Selected.'">
					<input type="hidden" name="Select_Niveau" value="'.$Id_Niveau_Selected.'">
					<input type="hidden" name="Tab" value="Evaluations">

					<div class="input-group mb-3">
						<select name="Select_Form" class="form-select" autocomplete="off">
							<option value="">Sélectionner une version</option>';

							$RsVersions = mysqli_query($db, "
							SELECT * FROM `Evaluations_Forms` 
							WHERE Id_Formation = '$Id_Formation_Selected' 
							AND Id_Niveau = '$Id_Niveau_Selected'");
							while ($data_Versions = mysqli_fetch_assoc($RsVersions)) {
								$Id_Form 		= $data_Versions['Id_Form'];
								$Version 		= $data_Versions['Version'];
								$Coefficient	= $data_Versions['Coefficient'];
								
								echo '<option value="'.$Id_Form.'"'; IF ($Id_Form==$Id_Form_Selected) { echo ' selected'; } echo '>Version '.$Version.'</option>';
							}

						echo '
						</select>
						<button type="submit" class="btn btn-primary"><i class="fa fa-check"></i></button>
					</div>
				</form>';
				
				IF ($Id_Form_Selected!="") {
					$RsForm_Selected = mysqli_query($db, "SELECT * FROM Evaluations_Forms WHERE Id_Form = '$Id_Form_Selected'");
					$data_Form_Selected = mysqli_fetch_assoc($RsForm_Selected);
						$Coefficient_Selected = $data_Form_Selected['Coefficient'] ?? 0;

					///
					echo '
					<form action="" method="post">
						<input type="hidden" name="Select_Formation" value="'.$Id_Formation_Selected.'">
						<input type="hidden" name="Select_Niveau" value="'.$Id_Niveau_Selected.'">
						<input type="hidden" name="Select_Form" value="'.$Id_Form_Selected.'">
						<input type="hidden" name="Tab" value="Evaluations">

						<div class="input-group mb-3">
							<span class="input-group-text">Coefficient : </span>
							<input type="text" class="form-control" name="UP_Coeffient" value="'.$Coefficient_Selected.'">
							<button type="submit" class="btn btn-primary"><i class="fa fa-check"></i></button>
						</div>
					</form>';
				}

				echo '
				<hr>

				<form action="" method="post">
					<input type="hidden" name="Select_Formation" value="'.$Id_Formation_Selected.'">
					<input type="hidden" name="Select_Niveau" value="'.$Id_Niveau_Selected.'">
					<input type="hidden" name="Tab" value="Evaluations">

					<div class="input-group mb-3">
						<span class="input-group-text">Ou </span>
						<input type="text" class="form-control" name="New_Version" value="" placeholder="Créer une version">
						<button type="submit" class="btn btn-primary"><i class="fa fa-check"></i></button>
					</div>
				</form>
			</div>
			<div class="col-lg-9">';

				IF ($Id_Form_Selected=="") { echo '<h4>Merci de bien vouloir sélectionner une version</h4>'; }
				Else {
					echo '
					<form action="" method="post">
						<input type="hidden" name="Select_Formation" value="'.$Id_Formation_Selected.'">
						<input type="hidden" name="Select_Niveau" value="'.$Id_Niveau_Selected.'">
						<input type="hidden" name="Select_Form" value="'.$Id_Form_Selected.'">
						<input type="hidden" name="Add_Question" value="Yes">
						<input type="hidden" name="Tab" value="Evaluations">';

						echo '
						<div class="input-group mb-3">
							<input type="text" class="form-control" name="Question" value="" placeholder="Ajouter une question">
							<button type="submit" class="btn btn-primary"><i class="fa fa-check"></i></button>
						</div>
					</form>';

					///
					$RsQuestions = mysqli_query($db, "SELECT * FROM `Evaluations_Questions` WHERE Id_Form = '$Id_Form_Selected'");
					while ($data_Questions = mysqli_fetch_assoc($RsQuestions)) {
						$Id_Question 	= $data_Questions['Id_Question'];
						$Question 		= $data_Questions['Question'];

						echo '
						<form action="" method="post">
							<input type="hidden" name="Select_Formation" value="'.$Id_Formation_Selected.'">
							<input type="hidden" name="Select_Niveau" value="'.$Id_Niveau_Selected.'">
							<input type="hidden" name="Select_Form" value="'.$Id_Form_Selected.'">
							<input type="hidden" name="Id_Question" value="'.$Id_Question.'">
							<input type="hidden" name="UP_Question" value="Yes">
							<input type="hidden" name="Tab" value="Evaluations">';

							echo '
							<div class="input-group mb-3">
								<input type="text" class="form-control" name="Question" value="'.$Question.'">
								<button type="submit" class="btn btn-primary"><i class="fa fa-check"></i></button>
							</div>
						</form>';

						echo '
						<form action="" method="post">
							<input type="hidden" name="Select_Formation" value="'.$Id_Formation_Selected.'">
							<input type="hidden" name="Select_Niveau" value="'.$Id_Niveau_Selected.'">
							<input type="hidden" name="Select_Form" value="'.$Id_Form_Selected.'">
							<input type="hidden" name="Id_Question" value="'.$Id_Question.'">
							<input type="hidden" name="Add_Response" value="Yes">
							<input type="hidden" name="Tab" value="Evaluations">';

							echo '
							<div class="input-group mb-3 ms-4">
								<span class="input-group-text">Type : </span>
								<select name="Response_Type" class="form-select" autocomplete="off">
									<option value="checkbox">checkbox</option>
									<option value="radio">radio</option>
									<option value="text">text</option>
								</select>
								<span class="input-group-text">Réponse : </span>
								<input type="text" class="form-control" name="Reponse" value="" placeholder="Ajouter une Réponse">
								<span class="input-group-text">Points : </span>
								<input type="text" class="form-control" name="Points" value="0">
								<button type="submit" class="btn btn-primary"><i class="fa fa-check"></i></button>
							</div>
						</form>';

						///
						$RsReponses = mysqli_query($db, "SELECT * FROM `Evaluations_Reponses` WHERE Id_Question = '$Id_Question'");
						while ($data_Reponses = mysqli_fetch_assoc($RsReponses)) {
							$Id_Reponse = $data_Reponses['Id_Reponse'];
							$Type 		= $data_Reponses['Type'];
							$Reponse 	= $data_Reponses['Reponse'];
							$Points 	= $data_Reponses['Points'];

							echo '
							<form action="" method="post">
								<input type="hidden" name="Select_Formation" value="'.$Id_Formation_Selected.'">
								<input type="hidden" name="Select_Niveau" value="'.$Id_Niveau_Selected.'">
								<input type="hidden" name="Select_Form" value="'.$Id_Form_Selected.'">
								<input type="hidden" name="Id_Question" value="'.$Id_Question.'">
								<input type="hidden" name="Id_Reponse" value="'.$Id_Reponse.'">
								<input type="hidden" name="UP_Response" value="Yes">
								<input type="hidden" name="Tab" value="Evaluations">';

								echo '
								<div class="input-group mb-3 ms-4">
									<span class="input-group-text">Type : </span>
									<select name="Response_Type" class="form-select" autocomplete="off">
										<option value="checkbox"'; IF ($Type=='checkbox') { echo ' selected'; } echo '>checkbox</option>
										<option value="radio"'; IF ($Type=='radio') { echo ' selected'; } echo '>radio</option>
										<option value="text"'; IF ($Type=='text') { echo ' selected'; } echo '>text</option>
									</select>
									<span class="input-group-text">Réponse : </span>
									<input type="text" class="form-control" name="Reponse" value="'.$Reponse.'">
									<span class="input-group-text">Points : </span>
									<input type="text" class="form-control" name="Points" value="'.$Points.'">
									<button type="submit" class="btn btn-primary"><i class="fa fa-check"></i></button>
								</div>
							</form>';
						}
					}
				}

			echo '
			</div>
		</div>';
	}

echo '
</div>';
?>
