<?php
///
IF (isset($_POST['UP_Formateur'])) {
	$Active			= $_POST['Active'];
	$Formateur		= $_POST['Formateur'];
	$Public_Email	= $_POST['Public_Email'];
	$Photo			= SEO($Formateur);
	$Presentation	= addslashes($_POST['Presentation']);
	$Portfolio		= $_POST['Portfolio'];
	$User			= $_POST['User'];
	$Pass			= $_POST['Pass'];

	mysqli_query($db, "
	UPDATE Formateurs SET 
	Active			= \"$Active\", 
	Formateur		= \"$Formateur\", 
	Public_Email	= \"$Public_Email\", 
	Photo			= \"$Photo\", 
	Presentation	= \"".$Presentation."\", 
	Portfolio		= \"".$Portfolio."\", 
	User			= \"$User\" 
	WHERE Id_Formateur = '$Id_Formateur_Selected'");
	
	IF ($Pass!="") {
		$Encode_Password = sha1(md5($Pass));

		///
		mysqli_query($db, "UPDATE Formateurs SET Pass = \"$Encode_Password\" WHERE Id_Formateur = '$Id_Formateur_Selected'");
	}

	///
	$Photo_File = $_FILES['Photo_File'] ?? "";
	$Size = $Photo_File['size'] ?? 0;
	
	IF ($Size>0) {
		$AuthExtensions	= array("jpg","jpeg");

		$Photo_Name	= $Photo;

		$LowerName	= strtolower($Photo_File['name']);
		$TmpExt		= explode('.', $LowerName);
		$FileExt	= end($TmpExt);

		$Destination_Folder = "./assets/images/formateurs";
		$Destination_File	= "$Destination_Folder/$Photo_Name.jpg";
		
		if(is_dir($Destination_Folder)) {
			$FileTmp = $Photo_File['tmp_name'] ?? '';

			IF (in_array($FileExt,$AuthExtensions)!==false){
				IF (move_uploaded_file($FileTmp, $Destination_File)) {}
				Else { echo "<p>Upload Failed</p>"; }
			}
		}
		Else {
			echo "<p>Folder Failed</p>";
		}
	}

}

///
$RsFormateur = mysqli_query($db, "SELECT * FROM Formateurs WHERE Id_Formateur = '$Id_Formateur_Selected'");
$data_Formateur = mysqli_fetch_assoc($RsFormateur);
	$Active			= $data_Formateur['Active'];
	$Formateur		= $data_Formateur['Formateur'];
	$Public_Email	= $data_Formateur['Public_Email'];
	$Photo			= $data_Formateur['Photo'];
	$Presentation	= $data_Formateur['Presentation'];
	$Portfolio		= $data_Formateur['Portfolio'];
	$User			= $data_Formateur['User'];
	$Pass			= $data_Formateur['Pass'];

//	Pour que l'image s'actualise à chaque changement
$refresh = date('y-m-d-h-i-s');

///
echo '
<hr>
<form action="" method="post" enctype="multipart/form-data" class="mt-4 mb-4 up-fiche">
	<input type="hidden" name="Select_Formateur" value="'.$Id_Formateur_Selected.'">
	<input type="hidden" name="UP_Formateur" value="Yes">

	<h4 class="mb-4 float-start">Modifier la fiche formateur :</h4> 
	
	<div class="float-end mb-4 fw-bold">
		'.$Formateur.' <img src="'.$Base_URL.'/assets/images/formateurs/'.$Photo.'.jpg?refresh='.$refresh.'" alt="'.$Formateur.'" title="'.$Formateur.'" class="rounded-circle shadow-1-strong ms-2" width="100" height="100">
	</div>

	<div class="input-group mt-4 mb-3">
		<span class="input-group-text">Active :</span>
		<select name="Active" class="form-select" autocomplete="off">
			<option value="1"'; IF ($Active==1) { echo ' selected'; } echo '>Oui</option>
			<option value="0"'; IF ($Active==0) { echo ' selected'; } echo '>Non</option>
		</select>
	</div>

	<div class="input-group mb-3">
		<span class="input-group-text">Formateur :</span>
		<input type="text" class="form-control" name="Formateur" value="'.$Formateur.'" readonly>
	</div>

	<div class="input-group mb-3">
		<span class="input-group-text">Photo :</span>
		<input type="file" name="Photo_File" class="form-control">
		<input type="submit" class="btn btn-primary btn-sm" value="Modifier">
	</div>

	<div class="input-group mb-3">
		<span class="input-group-text">Public Email :</span>
		<input type="text" class="form-control" name="Public_Email" value="'.$Public_Email.'">
	</div>

	<span class="input-group-text mt-3">Présentation :</span>
	<textarea class="form-control editor" name="Presentation">'.$Presentation.'</textarea>

	<div class="input-group mb-3 mt-3">
		<span class="input-group-text">Portfolio :</span>
		<input type="text" class="form-control" name="Portfolio" value="'.$Portfolio.'">
	</div>

	<div class="input-group mb-3">
		<span class="input-group-text">Utilisateur :</span>
		<input type="text" class="form-control" name="User" value="'.$User.'">
	</div>

	<div class="input-group mb-3">
		<span class="input-group-text">Pass :</span>
		<input type="password" class="form-control" name="Pass" value="">
	</div>
	<button type="submit" class="btn btn-primary">Modifier</button>
</form>';
?>

