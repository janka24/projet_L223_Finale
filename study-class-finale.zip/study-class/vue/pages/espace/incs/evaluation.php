<?php
$RsNiveau_Selected = mysqli_query($db, "SELECT * FROM Formation_Niveaux WHERE Id_Niveau = '$Id_Niveau_Selected'");
$data_Niveau_Selected = mysqli_fetch_assoc($RsNiveau_Selected);
	$Niveau_Selected = $data_Niveau_Selected['Niveau_Label'];

echo '
<div class="row justify-content-xl-center gy-3 gy-sm-4">
	<h4>Evaluation : '.$Niveau_Selected.'</h4>';
	
	IF (isset($_POST['Send_Eval']) AND !empty($_POST['r'])) {
		///
		$RsEval_Infos = mysqli_query($db, "
		SELECT 
		`Evaluations_Forms`.`Id_Form` AS Id_Form, 
		`Evaluations_Forms`.`Coefficient` AS Coefficient, 
		SUM(`Evaluations_Reponses`.`Points`) AS Possibles_Points 
		FROM `Evaluations_Forms`, `Evaluations_Questions`, `Evaluations_Reponses` 
		WHERE 
		`Evaluations_Forms`.`Id_Form` = `Evaluations_Questions`.`Id_Form`
		AND `Evaluations_Questions`.`Id_Question` = `Evaluations_Reponses`.`Id_Question` 
		AND `Evaluations_Forms`.`Id_Formation` = '$Id_Formation_Selected' 
		AND `Evaluations_Forms`.`Id_Niveau` = '$Id_Niveau_Selected' 
		AND `Evaluations_Reponses`.`Points` > 0 
		GROUP BY `Evaluations_Forms`.`Id_Form`");
		$data_Eval_Infos = mysqli_fetch_assoc($RsEval_Infos);
			$EI_Id_Form		= $data_Eval_Infos['Id_Form'] ?? 0;
			$EI_Coefficient	= $data_Eval_Infos['Coefficient'] ?? 0;
			$EI_Possibles	= $data_Eval_Infos['Possibles_Points'] ?? 0;

		///
		$R_Array = $_POST['r'] ?? "";
		$Total_Points = 0;

		///
		foreach($R_Array AS $Id_Reponse => $Value) {
			$RsTest_Response = mysqli_query($db, "SELECT * FROM `Evaluations_Reponses` WHERE Id_Reponse = $Id_Reponse");
			$data_Test_Response = mysqli_fetch_assoc($RsTest_Response);
				$Type		= $data_Test_Response['Type'] ?? "";
				$Reponse	= $data_Test_Response['Reponse'] ?? "";
				$Points		= $data_Test_Response['Points'] ?? 0;

			//	Compare la valeur postée à la réponse attendue dans la base...
			IF ($Type=="text") {
				IF (mb_strtolower($Reponse)==mb_strtolower($Value)) {
					$Total_Points = $Total_Points+$Points;
				}
			}

			Else {
				$Total_Points = $Total_Points+$Points;
			}
		}

		$Var_100	= 100/$EI_Possibles;
		$Var_On_100	= $Total_Points*$Var_100;
		$Score		= round($Var_On_100, 0);
		$Date_Score	= date('Y-m-d H:i:s');

		echo "<p><strong>Vous avez eu un score de $Score/100 à votre évaluation !</strong></p>";

		///
		mysqli_query($db,"INSERT INTO Evaluations_Scores (`Id_Score`, `Id_Form`, `Coefficient`, `Id_Etudiant`, `Score`, `Date_MAJ`) 
		VALUES (NULL, \"$EI_Id_Form\", \"$EI_Coefficient\", \"$Id_Etudiant\", \"$Score\", \"$Date_Score\")");
	}

	Else {
		$Possibles_Points = 0;

		echo '
		<form action="" method="post">
			<input type="hidden" name="Select_Formation" value="'.$Id_Formation_Selected.'">
			<input type="hidden" name="Evaluation" value="'.$Id_Niveau_Selected.'">';

			$RsEvaluation = mysqli_query($db, "SELECT * FROM Evaluations_Forms WHERE Id_Formation = '$Id_Formation_Selected' AND Id_Niveau = '$Id_Niveau_Selected'");
			while ($data_Evaluation = mysqli_fetch_assoc($RsEvaluation)) {
				$Id_Form		= $data_Evaluation['Id_Form'];
				$Version		= $data_Evaluation['Version'];
				$Coefficient	= $data_Evaluation['Coefficient'];
				
				$RsQuestions = mysqli_query($db, "SELECT * FROM Evaluations_Questions WHERE Id_Form = '$Id_Form'");
				while ($data_Questions = mysqli_fetch_assoc($RsQuestions)) {
					$Id_Question	= $data_Questions['Id_Question'];
					$Question		= $data_Questions['Question'];

					echo '
					<p><strong>'.$Question.'</strong></p>
					<ul class="list-inline">';
					
					$RsReponses = mysqli_query($db, "SELECT * FROM Evaluations_Reponses WHERE Id_Question = '$Id_Question'");
					while ($data_Reponses = mysqli_fetch_assoc($RsReponses)) {
						$Id_Reponse	= $data_Reponses['Id_Reponse'];
						$Type		= $data_Reponses['Type'];
						$Reponse	= $data_Reponses['Reponse'];
						$Points		= $data_Reponses['Points'];
						IF ($Points>0) { $Possibles_Points = $Possibles_Points+$Points; }

						IF ($Type=="text") {
							echo '
							<li><input type="text" name="r[\''.$Id_Reponse.'\']" value=""></li>';
						}
						Else {
							echo '
							<li><input type="'.$Type.'" name="r[\''.$Id_Reponse.'\']" value="1"> '.$Reponse.'</li>';
						}
					}

					echo '
					</ul>';
				}
			}

		echo '
			<input type="hidden" name="Id_Form" value="'.$Id_Form.'">
			<input type="hidden" name="Possibles_Points" value="'.$Possibles_Points.'">
			<button type="submit" name="Send_Eval" class="btn btn-outline-primary">Valider mes réponses</button>
		</form>';
	}

echo '
</div>';
?>
