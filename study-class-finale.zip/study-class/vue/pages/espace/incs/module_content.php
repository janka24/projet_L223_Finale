<?php
$RsModule_Selected = mysqli_query($db, "SELECT * FROM Formation_Modules WHERE Id_Module = '$Id_Module_Selected'");
$data_Module_Selected = mysqli_fetch_assoc($RsModule_Selected);
	$Module	= $data_Module_Selected['Titre'];
echo '
<div class="row justify-content-xl-center gy-3 gy-sm-4">
	<h4>Module : '.$Module.'</h4>

	<ul class="nav nav-tabs" role="tablist">
		<li class="nav-item" role="presentation">
			<button class="nav-link active" id="Formation-tab" data-bs-toggle="tab" data-bs-target="#Formation" type="button" role="tab" aria-controls="Formation" aria-selected="true">Formation</button>
		</li>
		<li class="nav-item" role="presentation">
			<button class="nav-link" id="Ressources-tab" data-bs-toggle="tab" data-bs-target="#Ressources" type="button" role="tab" aria-controls="Ressources" aria-selected="false">Ressources</button>
		</li>
		<li class="nav-item" role="presentation">
			<button class="nav-link" id="Exercices-tab" data-bs-toggle="tab" data-bs-target="#Exercices" type="button" role="tab" aria-controls="Exercices" aria-selected="false">Exercices</button>
		</li>
	</ul>

	<div class="tab-content">
		<div class="tab-pane fade show active" id="Formation" role="tabpanel" aria-labelledby="Formation-tab">
			<p><strong><em>Table des matières inspirées de la chaine youtube Grafikart...</em></strong></p>';
			require("lorem.php");
		echo '
		</div>
		<div class="tab-pane fade" id="Ressources" role="tabpanel" aria-labelledby="Ressources-tab">';
			require("lorem.php");
		echo '
		</div>
		<div class="tab-pane fade" id="Exercices" role="tabpanel" aria-labelledby="Exercices-tab">';
			require("lorem.php");
		echo '
		</div>
	</div>
</div>';
?>
