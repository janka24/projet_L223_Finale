<?php
$RsInfos_Formation = mysqli_query($db, "
SELECT 
Formations.Id_Formation AS Id_Formation, 
Formations.Formation AS Formation, 
Formations_Etudiant.Date_Inscription AS Date_Inscription 
FROM Formations_Etudiant, Formations 
WHERE 
Formations_Etudiant.Id_Formation = Formations.Id_Formation 
AND Formations_Etudiant.Id_Etudiant = '$Id_Etudiant'
AND Formations.Id_Formation = '$Id_Formation_Selected'");
$data_Infos_Formation = mysqli_fetch_assoc($RsInfos_Formation);
	$Id_Formation		= $data_Infos_Formation['Id_Formation'];
	$Formation			= $data_Infos_Formation['Formation'];
	$Date_Inscription	= $data_Infos_Formation['Date_Inscription'];

echo '
<h1>Formation : '.$Formation.'</h1>

<div class="row mt-4">
	<div class="col-lg-3">';

		$RsModules_Niveaux = mysqli_query($db, "
		SELECT Formation_Modules.Id_Niveau, Niveau_Label FROM 
		Formation_Modules, Formation_Niveaux 
		WHERE Formation_Modules.Id_Niveau = Formation_Niveaux.Id_Niveau 
		AND Id_Formation = '$Id_Formation_Selected' 
		GROUP BY Formation_Modules.Id_Niveau");
		while ($data_Modules_Niveaux = mysqli_fetch_assoc($RsModules_Niveaux)) {
			$Id_Niveau = $data_Modules_Niveaux['Id_Niveau'];
			$Niveau_Label = $data_Modules_Niveaux['Niveau_Label'];
			echo '
			<form action="" method="post" class="w-100 text-center">
				<h5>'.$Niveau_Label.' :</h5>
				<input type="hidden" name="Select_Formation" value="'.$Id_Formation_Selected.'">
				<input type="hidden" name="Evaluation" value="'.$Id_Niveau.'">
				<button type="submit" class="btn btn-outline-primary">Passer l\'évaluation</button>
			</form>
			
			<ul class="list-group">';

			$RsModules = mysqli_query($db, "
			SELECT * FROM 
			Formation_Modules, Formation_Niveaux 
			WHERE Formation_Modules.Id_Niveau = Formation_Niveaux.Id_Niveau 
			AND Id_Formation = '$Id_Formation_Selected' 
			AND Formation_Modules.Id_Niveau = '$Id_Niveau'");

			while ($data_Modules = mysqli_fetch_assoc($RsModules)) {
				$Id_Module		= $data_Modules['Id_Module'];
				$Niveau_Label	= $data_Modules['Niveau_Label'];
				$Titre			= $data_Modules['Titre'];

				echo '
				<li class="list-group-item">
					<form action="" method="post" name="Mod_'.$Id_Module.'">
						<input type="hidden" name="Select_Formation" value="'.$Id_Formation_Selected.'">
						<input type="hidden" name="Select_Module" value="'.$Id_Module.'">
						<a href="#" onclick="document.forms[\'Mod_'.$Id_Module.'\'].submit()">'.$Titre.' <i class="fa fa-chevron-right ms-2 float-end"></i></a>
					</form>
				</li>';
			}

			echo '
			</ul>';
		}

	echo '
	</div>
	<div class="col-lg-9">';
		IF ($Id_Module_Selected!="") {
			require("module_content.php");
		}
		Else IF ($Id_Niveau_Selected!="") {
			require("evaluation.php");
		}
		Else {
			require("progression.php");
		}
	echo '
	</div>
</div>';
?>
