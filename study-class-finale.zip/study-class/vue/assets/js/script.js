$(document).ready(function() {
	$('.nav-scroll').on('click', function() {
		var page = $(this).attr('data-target');
		var speed = 750;
		$('html, body').animate( { scrollTop: $(page).offset().top-100 }, speed ); // Go
		return false;
	});
});

if ($('#Chk_Privacy').length > 0) {
	const Chk_Privacy = document.getElementById('Chk_Privacy');
		
	Chk_Privacy.onclick = function() {
		var send_form_btn = document.getElementById('send_form_btn');
		if(Chk_Privacy.checked===true) {send_form_btn.setAttribute('type', 'submit');}
		else {send_form_btn.setAttribute('type', 'button');}
	}
};
