<?php
$Import_Content = '
<style>.editor { min-height:30vh !important; width:100%; }</style>
<script src="'.$Base_URL.'/assets/js/tinymce/tinymce.min.js"></script>
<script>
tinymce.init({
	language:"fr_FR",
    selector:".editor",
    entity_encoding:"raw",
    menubar:false,
    browser_spellcheck:true,

    plugins: [
         "link code lists wordcount paste"        
   ],

   relative_urls: false,

   toolbar1: "undo redo | bold italic underline | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link code",
 });
</script>';
