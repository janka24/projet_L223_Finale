<?php
$Login_Etudiant		= $_POST['Login_Etudiant'] ?? "";
$Login_Admin		= $_POST['Login_Admin'] ?? "";
$Login_Formateur	= $_POST['Login_Formateur'] ?? "";

$Password			= $_POST['Password'] ?? "";

$Etudiant			= "";
$Formateur			= "";
$Administrateur		= "";

$Subsc_Error		= "";

IF (isset($_GET['Route']) AND $_GET['Route']=="logout") {
	session_destroy();
	header("Location:../");
}


IF (isset($_POST['Subscribe'])) {
	print_r($_POST);
	$Subsc_Etudiant		= $_POST['Etudiant'] ?? "";
	$Subsc_Utilisateur	= $_POST['Utilisateur'] ?? "";
	$Subsc_Password		= $_POST['Password'] ?? "";
	$Subsc_Confirmation	= $_POST['Confirmation'] ?? "";

	IF (strlen($Subsc_Password)<6 OR $Subsc_Password!=$Subsc_Confirmation) {
		$Subsc_Error = '<p class="text-danger">Votre mot de passe ou sa confirmation est incorrect</p>';
	}
	Else IF (strlen($Subsc_Etudiant)<4) {
		$Subsc_Error = '<p class="text-danger">Votre nom est incorrect</p>';
	}
	
	Else IF (!filter_var($Subsc_Utilisateur, FILTER_VALIDATE_EMAIL)) {
		$Subsc_Error = '<p class="text-danger">Votre adresse email est incorrecte</p>';
	}
	
	Else {
		$Encode_Subsc_Password = sha1(md5($Subsc_Password));

		mysqli_query($db,"INSERT INTO Etudiants (`Id_Etudiant`, `Etudiant`, `Utilisateur`, `Pass`) 
		VALUES (NULL, \"$Subsc_Etudiant\", \"$Subsc_Utilisateur\", \"$Encode_Subsc_Password\")");

		$RsLogin = mysqli_query($db, "SELECT sha1(md5(CONCAT(`Id_Etudiant`,'-',`Etudiant`,'-',`Utilisateur`))) AS E_Auth_Code FROM Etudiants WHERE Utilisateur = '$Subsc_Utilisateur' AND Pass = '$Encode_Subsc_Password'");
		$Is_Login = mysqli_num_rows($RsLogin) ?? 0;

		IF ($Is_Login>0) {
			$data_Login = mysqli_fetch_assoc($RsLogin);
			$E_Auth_Code = $data_Login['E_Auth_Code'];

			$_SESSION['E_Auth_Code'] = $E_Auth_Code;
			header("Location:$Base_URL/mon-espace");
		}
	}
}

///	Administrateur
IF ($Login_Admin!="" AND $Password!="") {

	$Password = sha1(md5("$Password"));

	$RsUser = mysqli_query($db, "SELECT sha1(md5(CONCAT(`Id_Administrateur`,'-',`Administrateur`,'-',`User`))) AS A_Auth_Code FROM Administrateurs WHERE User = '$Login_Admin' AND Pass = '$Password'");
	$Is_User = mysqli_num_rows($RsUser) ?? 0;

	IF ($Is_User>0) {
		$data_User = mysqli_fetch_assoc($RsUser);
		$A_Auth_Code = $data_User['A_Auth_Code'];

		$_SESSION['A_Auth_Code'] = $A_Auth_Code;
	}
}

IF (isset($_SESSION['A_Auth_Code']) AND $_SESSION['A_Auth_Code']!="") {
	$A_Auth_Code = $_SESSION['A_Auth_Code'];
	$RsAdministrateur = mysqli_query($db, "SELECT * FROM `Administrateurs` WHERE sha1(md5(CONCAT(`Id_Administrateur`,'-',`Administrateur`,'-',`User`))) = '$A_Auth_Code'");
	$Is_Administrateur = mysqli_num_rows($RsAdministrateur) ?? 0;

	IF ($Is_Administrateur>0) {
		$data_Administrateur = mysqli_fetch_assoc($RsAdministrateur);
		$Id_Administrateur	= $data_Administrateur['Id_Administrateur'];
		$Administrateur		= $data_Administrateur['Administrateur'];
	}
}

///	Formateur
IF ($Login_Formateur!="" AND $Password!="") {

	$Password = sha1(md5("$Password"));

	$RsUser = mysqli_query($db, "SELECT sha1(md5(CONCAT(`Id_Formateur`,'-',`Formateur`,'-',`Utilisateur`))) AS F_Auth_Code FROM Formateurs WHERE Utilisateur = '$Login_Admin' AND Pass = '$Password'");
	$Is_User = mysqli_num_rows($RsUser) ?? 0;

	IF ($Is_User>0) {
		$data_User = mysqli_fetch_assoc($RsUser);
		$F_Auth_Code = $data_User['F_Auth_Code'];

		$_SESSION['F_Auth_Code'] = $F_Auth_Code;
	}
}

IF (isset($_SESSION['F_Auth_Code']) AND $_SESSION['F_Auth_Code']!="") {
	$F_Auth_Code = $_SESSION['F_Auth_Code'];
	$RsFormateur = mysqli_query($db, "SELECT * FROM `Formateurs` WHERE sha1(md5(CONCAT(`Id_Formateur`,'-',`Formateur`,'-',`Utilisateur`))) = '$F_Auth_Code'");
	$Is_Formateur = mysqli_num_rows($RsFormateur) ?? 0;

	IF ($Is_Formateur>0) {
		$data_Formateur = mysqli_fetch_assoc($RsFormateur);
		$Id_Formateur	= $data_Formateur['Id_Formateur'];
		$Formateur		= $data_Formateur['Formateur'];
	}
}


///	Etudiant
IF ($Login_Etudiant!="" AND $Password!="") {

	$Password = sha1(md5("$Password"));

	$RsUser = mysqli_query($db, "SELECT sha1(md5(CONCAT(`Id_Etudiant`,'-',`Etudiant`,'-',`Utilisateur`))) AS E_Auth_Code FROM Etudiants WHERE Utilisateur = '$Login_Etudiant' AND Pass = '$Password'");
	$Is_User = mysqli_num_rows($RsUser) ?? 0;

	IF ($Is_User>0) {
		$data_User = mysqli_fetch_assoc($RsUser);
		$E_Auth_Code = $data_User['E_Auth_Code'];

		$_SESSION['E_Auth_Code'] = $E_Auth_Code;
	}
}

IF (isset($_SESSION['E_Auth_Code']) AND $_SESSION['E_Auth_Code']!="") {
	$E_Auth_Code = $_SESSION['E_Auth_Code'];
	$RsEtudiant = mysqli_query($db, "SELECT * FROM `Etudiants` WHERE sha1(md5(CONCAT(`Id_Etudiant`,'-',`Etudiant`,'-',`Utilisateur`))) = '$E_Auth_Code'");
	$Is_Etudiant = mysqli_num_rows($RsEtudiant) ?? 0;

	IF ($Is_Etudiant>0) {
		$data_Etudiant = mysqli_fetch_assoc($RsEtudiant);
		$Id_Etudiant	= $data_Etudiant['Id_Etudiant'];
		$Etudiant		= $data_Etudiant['Etudiant'];
	}
}
?>
