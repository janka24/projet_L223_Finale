<?php
require("../controleur/identification.php");

$Base_URL = "http://study-class.fr";
//	$Base_URL = "http://localhost/study-class";

$Route		= $_GET['Route'] ?? "";
$Page		= $_GET['Page'] ?? "";

IF ($Route=="formation") {
	require("../modele/formation_details.php");
	$Route = "./pages/includes/formation_details.php";
}

Else IF ($Route=="mon-espace") {
	IF ($Page=="") {
		$Route = "./pages/espace/index.php";
	}

	Else {
		$Route = "./pages/espace/$Page.php";
	}
}

Else IF ($Route=="admin") {
	require("../modele/formations_liste.php");
	require("../modele/formateurs_liste.php");
	require("../modele/func_SEO.php");
	$Route = "./pages/admin/index.php";
}

Else IF ($Page=="404") {
	$Route = "./pages/includes/404.php";
}

Else {
	require("../modele/formations_liste.php");
	require("../modele/formateurs_liste.php");
	$Route = "./pages/accueil.php";
}
?>
